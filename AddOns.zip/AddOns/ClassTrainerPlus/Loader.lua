ClassTrainerFrame_LoadUI = function()
    ClassTrainerPlusFrame_Show()
end
