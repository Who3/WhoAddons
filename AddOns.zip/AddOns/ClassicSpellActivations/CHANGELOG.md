# ClassicSpellActivations

## [1.13.8](https://github.com/rgd87/ClassicSpellActivations/tree/1.13.8) (2019-09-03)
[Full Changelog](https://github.com/rgd87/ClassicSpellActivations/compare/1.13.7...1.13.8)

- Exorcism  
