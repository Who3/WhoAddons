# Quartz

## [3.5.1](https://github.com/Nevcairiel/Quartz/tree/3.5.1) (2019-08-27)
[Full Changelog](https://github.com/Nevcairiel/Quartz/compare/3.5.0...3.5.1)

- Add the file id for the samwise icon  
- Fix leakage  
- Try to get tradeskill working on classic  
